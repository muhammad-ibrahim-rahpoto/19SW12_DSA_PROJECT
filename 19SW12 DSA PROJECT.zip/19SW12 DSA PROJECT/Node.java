import java.util.Scanner;
import java.lang.*;
public class Node
{
	public int ID;
	public String proName;
	public double prePrice; //   product price
	public int quantity;
    public Node next;
    public static Node head = null;
    static Scanner sc = new Scanner (System.in);
    static Scanner sca = new Scanner (System.in);
    static Scanner scan = new Scanner (System.in);

	//      for entering(saving) 1st record in list
	 public static void beg()
	 {
		int id; //  quant    for quantity
		int quant;
		String name;
		double pre; //  pre for price
		Node t = new Node();
		System.out.print("\t\t\tEnter product Name:-");
		name = sc.nextLine();
		t.proName = name;
		System.out.print("\t\t\tEnter product ID:-");
		id = sc.nextInt();
		t.ID = id;
		System.out.print("\t\t\tEnter product price:-");
		pre = sc.nextDouble();
		t.prePrice = pre;
		System.out.print("\t\t\tEnter product quantity:-");
		quant = sc.nextInt();
		t.quantity = quant;
		t.next = head;
		head = t;
		System.out.print("\n\n\t\t\t\tThis product is Inserted!\n\n\n");
	 }
	// for entering(saving) 2nd and onward records in list
		public static void end()
		{
		int id; //   quant for quantity
		int quant;
		String name = new String();
		double pre; //  pre for price
		Node t = new Node();
		Node p = head;
		System.out.print("\t\t\tEnter product Name:-");
		name = sca.nextLine();
		t.proName = name;
		System.out.print("\t\t\tEnter product ID:-");
		id = sca.nextInt();
		t.ID = id;
		System.out.print("\t\t\tEnter product price:-");
		pre = sca.nextDouble();
		t.prePrice = pre;
		System.out.print("\t\t\tEnter product quantity:-");
		quant = sca.nextInt();
		t.quantity = quant;
			while (p.next != null)
			{
			p = p.next;
			}
				p.next = t;
				t.next = null;
			System.out.print("\n\n\t\t\t\tThis product is Inserted!\n\n\n");
		}

		//delete method
		public static void delPro()
		{
			display();
			int id;
			Node cur = head;
			Node pre = head;
			System.out.print("\n\nEnter ID to delete that product:\n\n");
			id = sc.nextInt();
			 if (head == null)
			 {
			System.out.print("List is empty");
			System.out.print("\n");
			 }
		int pos = 0;
		int count = display(); //   for load no of nodes
		pos = search(id); //   for check weather desire node is exist or not
		if (pos <= count)
		{

			while (cur.ID != id)
			{ //  for delete middle area products
				pre = cur;
				cur = cur.next;
			}
			pre.next = cur.next;
			System.out.print("\n<<item is deleted>>\n");
		}
		else
		{
			System.out.print("\n<<<Not found>>\n\n");
		}
		}

	// modify method
		public static void modify()
		{
			int id;
			int new_quantity;
			double pre; //    pre for price
			String pName = new String(); //   pName for new name
			if (head == null)
			{
			System.out.print("List is empty");
			System.out.print("\n");
			}
		else
		{
			System.out.print("\n\nEnter ID to modify product Name,product price and its quantity:\n");
			id = sc.nextInt();
			Node cur = head;
			int pos = 0;
			int count = display(); //   for load no of nodes
		pos = search(id); //   for check weather desire node is exist or not
		if (pos <= count)
		{

			while (cur.ID != id)
			{
				cur = cur.next;
			}
			System.out.print("\nOld Name : ");
			System.out.print(cur.proName);
			System.out.print("\nOld Price : ");
			System.out.print(cur.prePrice);
			System.out.print("\nOld Quantity : ");
			System.out.print(cur.quantity);
			System.out.print("\n");
			System.out.print("Enter new Name:");
			pName = scan.nextLine();
			cur.proName = pName;
			System.out.print("Enter new Price:");
			pre = scan.nextInt();
			cur.prePrice = pre;
			System.out.print("Enter new Quantity:");
			new_quantity = scan.nextInt();
			cur.quantity = new_quantity;

		}
		else
		{
			System.out.print(id);
			System.out.print(" is <<<Not found>>\n\n");
		}
		}
		}


	// display method
	public static int display()
	{
			int c = 0; //   c for count products
			Node p = head;
			System.out.print("Existing products are:\n");
			System.out.print("ID\t\tProduct Name\t\tPrice\t\tQuantity\n");
			while (p != null)
			{
				System.out.print(p.ID);
				System.out.print("\t\t");
				System.out.print(p.proName);
				System.out.print("\t\t\t\t");
				System.out.print(p.prePrice);
				System.out.print("\t\t");
				System.out.print(p.quantity);
				System.out.print("\t\t");
				System.out.print("\n");
				p = p.next;
				c = c + 1;
			}
			System.out.print("\nTotal products in our store is : ");
			System.out.print(c);
			System.out.print("\n\n\n");
			return c;
	}

		// buy function
		public static void buy()
		{
			String[] products ;
			products = new String [20];//   for display sold items
			double pay = 0;
			int no;
			double z=0;
			int c = 0;
			double price;
			int id;
			int i = 1;
			if (head == null)
			{
		System.out.print("\n<<<<There is no items to buy>>>>\n\n");
			}
		else
		{
			System.out.print("How many items you wanna to buy!\n");
			no = sc.nextInt();
				int count = display(); //   for store no of nodes  in c
			while (i <= no)
			{
			Node cur = head;
			int quant; //   quant   for quantity  and cho for choice
			int cho;
		System.out.print("Enter id of item that you want to buy: ");
	    int pos = 0;
		id = sc.nextInt();
		pos = search(id);
		if (pos <= count)
		{
								//     item is available in store
			while (cur.ID != id)
			{
				cur = cur.next;
			}

		System.out.print("How many quantities you want:");
		quant = sc.nextInt();
		if(quant <= cur.quantity)
		{ products[c] = cur.proName;
		c++;
		pay = cur.prePrice;
		z =  (cur.prePrice * quant); //     calculate Bill
		cur.quantity = cur.quantity - quant;} //    change quantity
		else { System.out.println("you have choosen high quantity . It is not avaliable");
		}
		i++;
		}
		else
		{
			System.out.print("\n<<<<<<<<<This item is not available in our store at this time>>>>\n\n");
		}
			}

	System.out.print("\n\n\n\n\t\t\tYou have bought : ");
	for ( i = 0;i < no;i++)
	{ //    show that item you have bought
		System.out.print(products[i]);
		System.out.print(",");
	}
	price = (int)z * (0.95); //    with 5% discount
		System.out.print("\n\nOriginal price : ");
		System.out.print(pay);
		System.out.print("\n with 5% discount: ");
		System.out.print(price);
		System.out.print("\nThank you! for the shopping\n\n");
		}
		}

		// search function
		public static int search(int id) //    for search item in list
		{
		 int count = 1;
		 Node p = head;
		 while (p != null)
		 {
			 if (p.ID == id)
			 {
				 break;
			 }
			 else
			 {
				 count++;
			 }
				 p = p.next;
		 }
		 return count;
		}

								//        Main function
	public static void main(String[] args)
	{
		Scanner sc2 = new Scanner (System.in);
		System.out.print(" MUHAMMAD IBRAHIM RAHPOTO   (19SW12)\n\n\n");
		System.out.print("<<<<<<<<<<<<<<<<<<<<<<<<   Market  >>>>>>>>>>>>>>>>>>>>\n");
		System.out.print("<<<<<<<<<<<<<<<<<<<<<<<<   Store         >>>>>>>>>>>>>>>>>>>>\n");
		System.out.print("<<<<<<<<<<<<<<<<<<<<<<<<   System        >>>>>>>>>>>>>>>>>>>>\n\n \t\t\t\t\t\t\n");

		int temp = 1;
		while (true)
		{
		int ch; //            choice for below message
		System.out.print("\t\tEnter 1 for ADD a new product \n\n\t\tEnter 2 to display all products \n\n\t\tEnter 3 for MODIFY Existing product\n\n");
		System.out.print("\t\tEnter 4 for Delete a particular product item\n\n\t\tEnter 5 for Buy something\n\n\t\tEnter 0 for exit\n\n");
		System.out.print("choice the number: ");
		ch = sc2.nextInt();
		switch (ch)
		{
		case 1:
		if (temp == 0)
		{ //    Second time and on ward this is only executed
		end();
		}
		if (temp == 1)
		{ //    this will be executed only one time
		beg();
		temp = 0;
		}
		break;
	case 2:
	System.out.print("1>> for Show Existing Items\n");
		int c;
		c = sc2.nextInt();
		if (c == 1)
		{
			display();
		}
		break;
	case 3:
		modify();
		break;
	case 4:
		delPro();
		break;
	case 5:
		buy();
		break;
	case 0:
			System.out.print("Exiting...");
			System.exit(0);
	default:
			 System.out.print("\t\t<<<Wrong choice>>>\n\n");
		}
		}
	}

}